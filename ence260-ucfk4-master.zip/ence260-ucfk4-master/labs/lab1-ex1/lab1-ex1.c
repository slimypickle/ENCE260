#include <avr/io.h>
#include "system.h"

int main (void)
{
    system_init ();

    /* Initialise port to drive LED 1.  */
    
    /* TODO.  */

    while (1)
    {

        /* Turn LED 1 on.  */

        /* TODO.  */

    }
}
