/*
Put your names, usernames, dates, description of the file etc here
*/


#include "system.h"

int main (void)
{
    system_init ();


    while (1)
    {



    }
}
